package db


const (
	defaultMaxConns = 10
)

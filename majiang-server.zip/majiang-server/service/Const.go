package service

var Msg_List = []string{
	"login",
	"ready",
	"huanpai",
	"dingque",
	"chupai",
	"peng",
	"gang",
	"hu",
	"guo",
	"chat",
	"quick_chat",
	"voice_msg",
	"emoji",
	"exit",
	"dispress",
	"dissolve_request",
	"dissolve_agree",
	"dissolve_reject",
}
